const readlineSync = require('readline-sync');
const cards = require('./deckofcards.json');
const utilities = require('./utilities.js');

utilities.mainMenu();